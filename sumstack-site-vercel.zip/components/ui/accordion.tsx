'use client';
import * as React from "react";
import { cn } from "@/components/ui/cn";

export function Accordion({ children, className = "" }: {children: React.ReactNode, className?: string}) {
  return <div className={cn("divide-y rounded-xl border", className)}>{children}</div>;
}
export function AccordionItem({ children }: {children: React.ReactNode}) { return <div>{children}</div>; }
export function AccordionTrigger({ children }: {children: React.ReactNode}) {
  const [open, setOpen] = React.useState(false);
  return (
    <button onClick={()=>setOpen(!open)} className="w-full text-left px-4 py-3 font-medium flex items-center justify-between">
      <span>{children}</span><span className="text-slate-400">{'▾'}</span>
    </button>
  );
}
export function AccordionContent({ children }: {children: React.ReactNode}) {
  return <div className="px-4 pb-4 text-sm text-slate-600">{children}</div>;
}
