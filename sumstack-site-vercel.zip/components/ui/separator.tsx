export function Separator() { return <div className="h-px w-full bg-slate-200" />; }
