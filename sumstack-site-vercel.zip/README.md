# Sumstack Marketing Site (Next.js + Tailwind + Framer Motion)

### Quick start
```bash
npm i
npm run dev
# or on Vercel: push to GitHub and import the repo, or drag-drop this folder
```

Assets are in `/public/assets`:
- `logo-light.png` (your PNG 1)
- `iphone-mock.png` (from Untitled design (4).png)
