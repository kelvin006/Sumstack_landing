'use client';
import React from "react";
import { motion, useScroll, useSpring } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Separator } from "@/components/ui/separator";
import { Check, ArrowRight, Shield, Banknote, Wallet, LineChart, Smartphone, CreditCard, Users, Building2, Receipt, FileText, Zap, Globe2, Mail, PlayCircle, Sparkles, ChevronRight, Star, Lock, Rocket, Github, Linkedin, Phone, MessageSquare } from "lucide-react";

const container = {
  hidden: { opacity: 0, y: 24 },
  show: { opacity: 1, y: 0, transition: { duration: 0.6, ease: "easeOut", staggerChildren: 0.06 } },
};
const item = { hidden: { opacity: 0, y: 16 }, show: { opacity: 1, y: 0, transition: { duration: 0.5, ease: "easeOut" } } };
const float = { initial: { y: 0 }, animate: { y: [0, -10, 0], transition: { duration: 6, repeat: Infinity, ease: "easeInOut" } } };

const features = [
  { icon: <Wallet className="h-6 w-6" />, title: "Smart Wallet", desc: "A business wallet that understands your spend and syncs it with your books automatically." },
  { icon: <Banknote className="h-6 w-6" />, title: "Bank Connections", desc: "Securely connect Nigerian bank accounts. We auto‑categorize inflows/outflows with AI." },
  { icon: <Users className="h-6 w-6" />, title: "Customers & Vendors", desc: "Keep contacts tidy. Link transactions and see histories at a glance." },
  { icon: <FileText className="h-6 w-6" />, title: "Quotes & Invoices", desc: "Create, send, and track quotes/invoices. Customers approve or pay online." },
  { icon: <CreditCard className="h-6 w-6" />, title: "Expense Cards", desc: "Issue virtual/physical cards for team spend. Set limits and get real‑time alerts." },
  { icon: <Receipt className="h-6 w-6" />, title: "Bills & Vendor Payments", desc: "Capture bills from email or upload and pay vendors directly from Sumstack." },
  { icon: <Zap className="h-6 w-6" />, title: "Utilities & Subscriptions", desc: "Pay and manage recurring business utilities with automated reminders." },
  { icon: <LineChart className="h-6 w-6" />, title: "Reports & Insights", desc: "Live dashboards for cash flow, P&L, and best‑selling items." },
];
const plans = [
  { name: "Starter", tagline: "Solo founders & micro‑businesses", price: "Free", cta: "Join waitlist", anchor: "#waitlist", highlights: ["Connect 1 bank account","Basic categorization","Create quotes & invoices","Email support"] },
  { name: "Growth", tagline: "Growing SMEs that want automation", price: "₦14,999/mo", featured: true, cta: "Start free trial", anchor: "#waitlist", highlights: ["Unlimited bank connections","AI categorization & rules","Expense cards (virtual)","Bills & vendor payments","Automated utilities","Smart reports & exports"] },
  { name: "Elite", tagline: "Teams with complex workflows", price: "Custom", cta: "Talk to sales", anchor: "#contact", highlights: ["Physical cards & limits","Advanced approvals","Multi‑entity reports","Priority support & SLA"] },
];
const logos = ["NIBSS‑ready","PCI‑aware","Bank‑grade security","Built for SMEs"];

function ProgressBar() {
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, { stiffness: 120, damping: 20, restDelta: 0.001 });
  return <motion.div style={{ scaleX }} className="fixed top-0 left-0 right-0 h-1 z-50 origin-left bg-[var(--brand)]" />;
}

export default function Page() {
  return (
    <div className="min-h-screen bg-white text-slate-900 scroll-smooth">
      <ProgressBar />

      <div aria-hidden className="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 1 }}
          className="absolute -top-24 -right-24 h-96 w-96 rounded-full blur-3xl"
          style={{ background: "radial-gradient(closest-side, rgba(9,102,118,0.25), transparent)" }} />
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 1, delay: .2 }}
          className="absolute -bottom-24 -left-24 h-[28rem] w-[28rem] rounded-full blur-3xl"
          style={{ background: "radial-gradient(closest-side, rgba(13,148,136,0.15), transparent)" }} />
      </div>

      <div className="w-full text-xs bg-[#063d46] text-white py-2">
        <div className="max-w-7xl mx-auto px-4 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Sparkles className="h-4 w-4" />
            <span className="opacity-90">Webinar: Overcoming Finance Management Issues — Thursdays</span>
          </div>
          <a href="#webinar" className="inline-flex items-center gap-1 underline underline-offset-4">Save my seat <ChevronRight className="h-3 w-3" /></a>
        </div>
      </div>

      <header className="sticky top-1 z-40 mx-2 rounded-2xl backdrop-blur supports-[backdrop-filter]:bg-white/70 bg-white/80 border shadow-sm">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between py-3">
            <a href="#top" className="flex items-center gap-3">
              <img src="/assets/logo-light.png" alt="Sumstack" className="h-8 w-auto" />
            </a>
            <nav className="hidden md:flex items-center gap-6 text-sm">
              <a href="#features" className="hover:opacity-70">Features</a>
              <a href="#pricing" className="hover:opacity-70">Pricing</a>
              <a href="#security" className="hover:opacity-70">Security</a>
              <a href="#resources" className="hover:opacity-70">Resources</a>
              <a href="#support" className="hover:opacity-70">Support</a>
            </nav>
            <div className="flex items-center gap-2">
              <a href="#signin"><Button variant="ghost" className="hidden md:inline-flex">Sign in</Button></a>
              <a href="#waitlist"><Button>Join waitlist</Button></a>
            </div>
          </div>
        </div>
      </header>

      <section id="top" className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-[#e6f2f4] to-transparent" />
        <motion.div variants={container} initial="hidden" animate="show"
          className="max-w-7xl mx-auto px-4 py-16 md:py-24 grid md:grid-cols-2 gap-10 items-center">
          <div>
            <motion.h1 variants={item} className="text-4xl md:text-6xl font-semibold leading-tight">
              Run your business money <span className="bg-clip-text text-transparent bg-gradient-to-r from-[var(--brand)] via-teal-600 to-emerald-600">beautifully</span>
            </motion.h1>
            <motion.p variants={item} className="mt-4 text-lg text-slate-600 max-w-xl">
              Sumstack is the all‑in‑one financial platform for Nigerian SMEs. Connect banks, issue cards, send invoices, pay vendors, and get live insights—without spreadsheet chaos.
            </motion.p>
            <motion.div variants={item} className="mt-6 flex flex-col sm:flex-row gap-3">
              <a href="#waitlist"><Button className="inline-flex items-center gap-2">Get started <ArrowRight className="h-4 w-4" /></Button></a>
              <a href="#demo"><Button variant="outline" className="inline-flex items-center gap-2">Watch demo <PlayCircle className="h-4 w-4" /></Button></a>
            </motion.div>
            <motion.div variants={item} className="mt-8 grid grid-cols-2 gap-4 text-sm">
              {logos.map((l,i)=> (
                <div key={i} className="flex items-center gap-2 opacity-80"><Shield className="h-4 w-4" />{l}</div>
              ))}
            </motion.div>
          </div>

          <motion.div initial={float.initial} animate={float.animate} className="relative">
            <div className="absolute -inset-8 rounded-[2rem] bg-gradient-to-br from-[var(--brand)]/10 via-teal-300/10 to-transparent blur-2xl" />
            <Card className="relative rounded-3xl shadow-2xl border-slate-200">
              <CardContent className="p-4 md:p-6">
                <img src="/assets/iphone-mock.png" alt="Sumstack iPhone mockup" className="rounded-2xl w-full h-auto" />
              </CardContent>
            </Card>
          </motion.div>
        </motion.div>
      </section>

      <section className="py-8 border-y bg-slate-50">
        <div className="overflow-hidden whitespace-nowrap">
          <motion.div initial={{ x: 0 }} animate={{ x: [0, -600, 0] }} transition={{ duration: 18, repeat: Infinity, ease: "linear" }} className="flex gap-10 items-center px-4">
            {["10× faster month‑end","85% auto‑categorized","Realtime insights","Built for SMEs","Bank‑grade security"].map((t,i)=> (
              <span key={i} className="text-slate-700 text-sm flex items-center gap-2"><Star className="h-4 w-4 text-[var(--brand)]" /> {t}</span>
            ))}
          </motion.div>
        </div>
      </section>

      <section id="features" className="py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4">
          <motion.div variants={container} initial="hidden" whileInView="show" viewport={{ once: true, margin: "-100px" }}>
            <motion.div variants={item} className="max-w-2xl">
              <h2 className="text-3xl md:text-5xl font-semibold">Everything you need to stay on top of money</h2>
              <p className="mt-3 text-slate-600">From quotes to reconciliation—Sumstack keeps finance ops tidy and automated.</p>
            </motion.div>
            <div className="mt-10 grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
              {features.map((f, i) => (
                <motion.div key={i} variants={item} className="group">
                  <Card className="rounded-2xl hover:shadow-xl transition-all border border-slate-200 hover:border-[var(--brand)]/40">
                    <CardHeader className="pb-2">
                      <div className="h-11 w-11 rounded-xl bg-[var(--brand)]/10 text-[var(--brand)] grid place-items-center mb-3 group-hover:scale-110 transition-transform">
                        {f.icon}
                      </div>
                      <CardTitle className="text-base">{f.title}</CardTitle>
                    </CardHeader>
                    <CardContent className="pt-0 text-sm text-slate-600">{f.desc}</CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      <section className="py-14 bg-gradient-to-b from-slate-50 to-white">
        <div className="max-w-7xl mx-auto px-4 grid md:grid-cols-2 gap-10 items-center">
          <div>
            <h3 className="text-2xl md:text-4xl font-semibold">From invoice to insight—no copy‑paste</h3>
            <p className="mt-3 text-slate-600">Sumstack auto‑categorizes transactions, links them to customers or vendors, and updates reports in the background.</p>
            <ul className="mt-4 space-y-2 text-sm">
              {["AI‑powered categorization with override rules","Approvals and spend controls for teams","Mobile‑first experience for receipts and cards","Exports to your accountant when you need it"].map((t, i) => (
                <li key={i} className="flex items-start gap-2"><Check className="h-4 w-4 mt-1 text-[var(--brand)]" />{t}</li>
              ))}
            </ul>
            <div className="mt-6 flex gap-3">
              <a href="#pricing"><Button>See pricing</Button></a>
              <a href="#contact"><Button variant="outline">Talk to sales</Button></a>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <Card className="rounded-2xl">
              <CardHeader className="pb-2"><CardTitle className="text-base flex items-center gap-2"><Smartphone className="h-4 w-4" /> Mobile</CardTitle></CardHeader>
              <CardContent className="pt-0 text-sm text-slate-600">Snap receipts, approve spend, and send invoices on the go.</CardContent>
            </Card>
            <Card className="rounded-2xl">
              <CardHeader className="pb-2"><CardTitle className="text-base flex items-center gap-2"><Building2 className="h-4 w-4" /> Vendors</CardTitle></CardHeader>
              <CardContent className="pt-0 text-sm text-slate-600">Keep bills and payments in sync with vendor statements.</CardContent>
            </Card>
            <Card className="rounded-2xl">
              <CardHeader className="pb-2"><CardTitle className="text-base flex items-center gap-2"><Globe2 className="h-4 w-4" /> Bank Sync</CardTitle></CardHeader>
              <CardContent className="pt-0 text-sm text-slate-600">Secure bank connections with auto‑refresh and matching.</CardContent>
            </Card>
            <Card className="rounded-2xl">
              <CardHeader className="pb-2"><CardTitle className="text-base flex items-center gap-2"><LineChart className="h-4 w-4" /> Insights</CardTitle></CardHeader>
              <CardContent className="pt-0 text-sm text-slate-600">Track cash flow, margins, and best‑selling items in real time.</CardContent>
            </Card>
          </div>
        </div>
      </section>

      <section id="security" className="py-12">
        <div className="max-w-7xl mx-auto px-4">
          <Card className="rounded-2xl border border-emerald-200/40 bg-gradient-to-r from-emerald-50 to-white">
            <CardContent className="p-6 md:p-8 grid md:grid-cols-3 gap-6 items-center">
              <div className="md:col-span-2">
                <h4 className="text-xl md:text-2xl font-semibold flex items-center gap-2"><Lock className="h-5 w-5 text-emerald-600" /> Bank‑grade security by default</h4>
                <p className="mt-2 text-sm text-slate-600">Encryption in transit and at rest, role‑based access, and activity logs. We design for PCI awareness, NIBSS‑readiness, and privacy best practices.</p>
              </div>
              <div className="flex gap-3 md:justify-end">
                <a href="#support"><Button variant="outline">Learn more</Button></a>
                <a href="#waitlist"><Button>Get started</Button></a>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      <section id="pricing" className="py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center max-w-2xl mx-auto">
            <h3 className="text-3xl md:text-5xl font-semibold">Simple pricing that scales with you</h3>
            <p className="mt-3 text-slate-600">Start free, upgrade when you need advanced automation and cards.</p>
          </div>
          <div className="mt-10 grid md:grid-cols-3 gap-6">
            {plans.map((p, i) => (
              <motion.div key={i} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: .5, delay: i * .08 }}>
                <Card className={`rounded-2xl ${p.featured ? 'border-[var(--brand)] shadow-xl' : ''}`}>
                  <CardHeader>
                    <div className="flex items-center gap-2">
                      {p.featured && <Star className="h-4 w-4 text-[var(--brand)]" />}
                      <CardTitle>{p.name}</CardTitle>
                    </div>
                    <div className="text-sm text-slate-600">{p.tagline}</div>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-semibold">{p.price}</div>
                    <ul className="mt-4 space-y-2 text-sm">
                      {p.highlights.map((h, j) => (
                        <li key={j} className="flex gap-2"><Check className="h-4 w-4 text-[var(--brand)] mt-1" />{h}</li>
                      ))}
                    </ul>
                    <a href={p.anchor}><Button className="w-full mt-6" variant={p.featured ? 'default' : 'outline'}>{p.cta}</Button></a>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 bg-slate-50" id="resources">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-6">
            {[1,2,3].map((n)=> (
              <motion.div key={n} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
                <Card className="rounded-2xl hover:shadow-lg transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-2 text-[var(--brand)] mb-3">
                      {Array.from({length:5}).map((_,i)=> <Star key={i} className="h-4 w-4" />)}
                    </div>
                    <p className="text-slate-700">“Switching to Sumstack cut our month‑end from days to hours. The AI categorization is scarily accurate, and invoices reconcile themselves.”</p>
                    <div className="mt-4 text-sm font-medium">Adaora • Retail SME, Lagos</div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section id="support" className="py-16 md:py-24">
        <div className="max-w-5xl mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-8 items-start">
            <div>
              <h3 className="text-3xl md:text-5xl font-semibold">We’ve got your back</h3>
              <p className="mt-3 text-slate-600">Browse our Help Center, tutorials, or talk to a human. We’re building with and for Nigerian businesses.</p>
              <div className="mt-6 flex gap-3">
                <a href="#support-faq"><Button>Help Center</Button></a>
                <a href="#contact"><Button variant="outline">Contact us</Button></a>
              </div>
            </div>
            <div id="support-faq">
              <Accordion>
                <AccordionItem>
                  <AccordionTrigger>What is Sumstack?</AccordionTrigger>
                  <AccordionContent>Sumstack is an all‑in‑one financial platform for Nigerian small businesses. Connect your bank, automate bookkeeping, and run quotes, invoices, bills, cards, and reports from one dashboard.</AccordionContent>
                </AccordionItem>
                <AccordionItem>
                  <AccordionTrigger>Do I need accounting experience?</AccordionTrigger>
                  <AccordionContent>No. Sumstack classifies transactions automatically and explains what changed. You can override or add simple rules.</AccordionContent>
                </AccordionItem>
                <AccordionItem>
                  <AccordionTrigger>How do payments work?</AccordionTrigger>
                  <AccordionContent>Send invoices with payment links. Customers can pay online; we reconcile the transaction automatically.</AccordionContent>
                </AccordionItem>
                <AccordionItem>
                  <AccordionTrigger>Can my team use cards?</AccordionTrigger>
                  <AccordionContent>Yes. Issue virtual or physical expense cards, set spend limits, and attach receipts from mobile.</AccordionContent>
                </AccordionItem>
              </Accordion>
            </div>
          </div>
        </div>
      </section>

      <section id="demo" className="py-12 bg-slate-50">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h4 className="text-2xl md:text-3xl font-semibold">See Sumstack in action</h4>
          <p className="mt-2 text-slate-600">Watch a quick product walkthrough—quotes, invoices, cards, and live reports.</p>
          <div className="mt-5">
            <a href="#webinar"><Button className="inline-flex items-center gap-2 bg-black text-white hover:bg-black/80"><PlayCircle className="h-4 w-4" /> Watch demo</Button></a>
          </div>
        </div>
      </section>

      <section id="webinar" className="py-16 md:py-24 bg-[var(--brand)] text-white relative overflow-hidden">
        <div className="absolute -inset-40 bg-[radial-gradient(ellipse_at_center,rgba(255,255,255,0.12),transparent_60%)]" />
        <div className="relative max-w-5xl mx-auto px-4 text-center">
          <h3 className="text-3xl md:text-5xl font-semibold">Overcoming Finance Management Issues in Your Business</h3>
          <p className="mt-3 text-white/80">Live product demo + Q&A every Thursday. See how Sumstack replaces spreadsheets and stitches your financial ops together.</p>
          <form className="mt-6 max-w-md mx-auto flex gap-3" action="#thanks">
            <Input placeholder="Enter your email" className="bg-white text-slate-900" required name="email" />
            <Button className="bg-black text-white hover:bg-black/80" type="submit">Save my seat</Button>
          </form>
        </div>
      </section>

      <section id="contact" className="py-16">
        <div className="max-w-6xl mx-auto px-4 grid md:grid-cols-2 gap-10">
          <div>
            <h4 className="text-2xl md:text-3xl font-semibold">Talk to sales</h4>
            <p className="mt-2 text-slate-600">Tell us about your business and we’ll tailor a walkthrough.</p>
            <form className="mt-6 space-y-3" action="#thanks">
              <Input placeholder="Full Name" required />
              <Input placeholder="Work Email" type="email" required />
              <Input placeholder="Company" />
              <div className="flex gap-3">
                <a href="#thanks"><Button>Request demo</Button></a>
                <a href="#waitlist"><Button variant="outline">Join waitlist</Button></a>
              </div>
            </form>
          </div>
          <Card className="rounded-2xl">
            <CardContent className="p-6 space-y-3 text-sm text-slate-700">
              <div className="flex items-center gap-2"><Phone className="h-4 w-4 text-[var(--brand)]" /> +234 • Coming soon</div>
              <div className="flex items-center gap-2"><Mail className="h-4 w-4 text-[var(--brand)]" /> hello@sumstack.app</div>
              <div className="flex items-center gap-2"><MessageSquare className="h-4 w-4 text-[var(--brand)]" /> Live chat (beta)</div>
              <Separator />
              <div className="text-xs text-slate-500">We typically reply within 1 business day.</div>
            </CardContent>
          </Card>
        </div>
      </section>

      <section id="thanks" className="py-6">
        <div className="max-w-4xl mx-auto px-4 text-center text-sm text-emerald-700">Thanks! We’ll be in touch soon.</div>
      </section>

      <footer className="py-12 border-t">
        <div className="max-w-7xl mx-auto px-4 grid md:grid-cols-5 gap-8">
          <div className="md:col-span-2">
            <img src="/assets/logo-light.png" alt="Sumstack" className="h-7 w-auto" />
            <p className="mt-3 text-sm text-slate-600 max-w-sm">Sumstack is an all‑in‑one financial platform designed to automate bookkeeping and accounting for small businesses in Nigeria.</p>
            <div className="mt-4 flex gap-2">
              <a href="mailto:hello@sumstack.app" aria-label="Email"><Button variant="outline" className="!px-3 !py-2"><Mail className="h-4 w-4" /></Button></a>
              <a href="#" aria-label="LinkedIn"><Button variant="outline" className="!px-3 !py-2"><Linkedin className="h-4 w-4" /></Button></a>
              <a href="#" aria-label="GitHub"><Button variant="outline" className="!px-3 !py-2"><Github className="h-4 w-4" /></Button></a>
            </div>
          </div>
          <div>
            <div className="font-semibold mb-3">Product</div>
            <ul className="space-y-2 text-sm text-slate-600">
              <li><a href="#features" className="hover:text-slate-900">Features</a></li>
              <li><a href="#pricing" className="hover:text-slate-900">Pricing</a></li>
              <li><a href="#security" className="hover:text-slate-900">Security</a></li>
              <li><a href="#roadmap" className="hover:text-slate-900">Roadmap</a></li>
            </ul>
          </div>
          <div>
            <div className="font-semibold mb-3">Company</div>
            <ul className="space-y-2 text-sm text-slate-600">
              <li><a href="#support" className="hover:text-slate-900">About</a></li>
              <li><a href="#support" className="hover:text-slate-900">Help Center</a></li>
              <li><a href="#resources" className="hover:text-slate-900">Tutorials</a></li>
              <li><a href="#contact" className="hover:text-slate-900">Contact</a></li>
            </ul>
          </div>
          <div>
            <div className="font-semibold mb-3">Legal</div>
            <ul className="space-y-2 text-sm text-slate-600">
              <li><a href="#" className="hover:text-slate-900">Terms</a></li>
              <li><a href="#" className="hover:text-slate-900">Privacy</a></li>
              <li><a href="#" className="hover:text-slate-900">Cookies</a></li>
            </ul>
          </div>
        </div>
        <div className="max-w-7xl mx-auto px-4 mt-10 text-xs text-slate-500 flex items-center justify-between">
          <span>© {new Date().getFullYear()} Sumstack. All rights reserved.</span>
          <a href="#top" className="inline-flex items-center gap-2 text-slate-600 hover:text-slate-800"><Rocket className="h-3.5 w-3.5" /> Back to top</a>
        </div>
      </footer>

      <motion.div initial={{ y: 100, opacity: 0 }} whileInView={{ y: 0, opacity: 1 }} viewport={{ once: true }} className="fixed bottom-4 right-4">
        <a href="#waitlist"><Button className="shadow-lg inline-flex items-center gap-2">Get Sumstack <ArrowRight className="h-4 w-4" /></Button></a>
      </motion.div>

      <div id="waitlist" className="sr-only" aria-hidden />
      <div id="roadmap" className="sr-only" aria-hidden />
      <div id="signin" className="sr-only" aria-hidden />
    </div>
  );
}
